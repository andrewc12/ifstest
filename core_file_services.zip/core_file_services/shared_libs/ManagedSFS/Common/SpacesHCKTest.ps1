﻿<#

    Copyright (c) 2014 Microsoft Corporation

    Module Name: Spaces verification test

    Abstract:

    This test creates mirror space on enclosure drives and verifies that files can be created on that.

    Author(s): umani

    Environment: User Mode

    Revision History:
    Basic pool,spaces creation on enclosure drives


    Description:
    A. Run the test on a node connected to Enclosure/s

#>

param (
    $EnclosureVPD = $null
    )

$sysRoot = $env:SystemRoot
$gacFilePath = "Assembly\Gac\Microsoft.Wtt.Log"
$gacdir = $sysRoot + "\" + $gacFilePath
$gacdir1 = $gacdir  + "\*2.2*"
$gacdirName = dir $gacdir1
$loggerPath = $gacdir + "\" + $gacdirName.Name
write $loggerPath

$lib = $loggerPath + "\" + "Microsoft.wtt.log.dll"
[Reflection.Assembly]::LoadFile($lib)

#6b. Enhanced data structures
[Reflection.Assembly]::Load("mscorlib.dll")

#7. Create logger object

$mins = (Get-Date).TimeOfDay.TotalMinutes
$fileName= "Spaces$mins"
$config = "`$console;`$logfile:file=$fileName.wtl,Writemode=overwrite"#,encoding=UNICODE"
$logger = new-object Microsoft.DistributedAutomation.Logger.TestLogger $config
$rollup = new-object Microsoft.DistributedAutomation.Logger.LevelRollup(0, 0, 0, 0, 0)
$pass = 0x1
$fail = 0x2
$scenario = 0

<#
    Description:
This function is used to write message to WTT log file

    Arguments:
text - string to write

Return Value:
None
#>
function WriteMessageToLogFile($text)
{
    $msg = new-object Microsoft.DistributedAutomation.Logger.LevelMessage $text
    $script:logger.Trace($msg)
}

<#
    Description:
    This function is used to write error message to WTT log file

    Arguments:   None

    Return Value:    None
#>
function WriteErrorToLogFile()
{
    $err = new-object Microsoft.DistributedAutomation.Logger.LevelError(0, 0, 0)
    $script:logger.Trace($err)
}

 <#
   Description:
   This function creates space on enclosure drives and verifies that files can be created on the space volume

   Arguments:      None

   Return Value:   None
 #>
 function CreateEnclosureMirrorSpace()
 {   
    trap [Exception] { 
          WriteErrorToLogFile
          write-host "Trapped Exception $($_.Exception.Message) "
          return
     }

     WriteMessageToLogFile "Testing enclosure with unique id: $EnclosureVPD"
     WriteMessageToLogFile "Test creates pool on enclosure drives and space, it creates partition on the space and verifies that files can be created on the space volume"
     if($EnclosureVPD -ne $null)
     {
         WriteMessageToLogFile "Enclosure to be tested"

         $outvar = get-storageenclosure -UniqueId $EnclosureVPD  | fl | out-string   
         WriteMessageToLogFile $outvar
         
         WriteMessageToLogFile "Get-physical disk with drives from Enclosure with Unique Id $EnclosureVPD"
         $PhysicalDisks = get-storageenclosure -UniqueId $EnclosureVPD |  Get-PhysicalDisk -Canpool $True
          if ($physicaldisks -eq $null)
         {
             WriteErrorToLogFile 
             WriteMessageToLogFile "Get-PhysicalDisk returned no drives"
             return 
         }
     }
     else
     {
         $PhysicalDisks = Get-PhysicalDisk -Canpool $True
         if ($physicaldisks -eq $null)
         {
             WriteErrorToLogFile 
             WriteMessageToLogFile "Get-PhysicalDisk returned no drives"
             return 
         }


         $outvar = Get-PhysicalDisk  -Canpool $True | ? enclosurenumber -NE $null | select FriendlyName,HealthStatus,Size,EnclosureNumber  | out-string
         WriteMessageToLogFile "Physicaldisks are "
         WriteMessageToLogFile $outvar
     }

     WriteMessageToLogFile "Creating Storage pool on enclosure drives "

     $TestPool = $null

     #if cluster is found create a pool with cluster resource
     $clus = get-cluster
     if($clus -ne $null)
     {
         Get-storagesubsystem *cluster* | Set-storagesubsystem  -AutomaticClusteringEnabled $false
         WriteMessageToLogFile "Cluster found $clus,create pool with 'Cluster' storageSubSystemFriendlyName"
          $TestPool = New-StoragePool -FriendlyName "($fileName)_Pool" -PhysicalDisks $PhysicalDisks -StorageSubSystemFriendlyName *Cluster*
         if ($TestPool -eq $null)
         {
             WriteErrorToLogFile 
             WriteMessageToLogFile "Pool creation failure"

             return 
         }
     }
     else
     {
         WriteMessageToLogFile "No cluster found,create pool with 'storage' storageSubSystemFriendlyName"        
         $TestPool = New-StoragePool -FriendlyName "($fileName)_Pool" -PhysicalDisks $PhysicalDisks -StorageSubSystemFriendlyName *storage*
         if ($TestPool -eq $null)
         {
             WriteErrorToLogFile 
             WriteMessageToLogFile "Pool creation failure"

             return 
         }
     }
     WriteMessageToLogFile "Storage pool size is $($TestPool.Size)"

     $ActualSpace = New-VirtualDisk -FriendlyName $fileName -StoragePoolUniqueId $TestPool.UniqueID -UseMaximumSize -ProvisioningType Fixed -ResiliencySettingName "Mirror"
     
     # Try to move disk from owner node to current node.
     $Computer = Get-WmiObject -Class Win32_ComputerSystem 
	
     WriteMessageToLogFile "Moving Virtual Disk to Current Node"
     $ActualSpace | Set-VirtualDisk -IsManualAttach $true
     $ActualSpace | Connect-VirtualDisk -StorageNodeName $Computer.Name.ToString()

     $disk = $ActualSpace | Get-Disk
     WriteMessageToLogFile "Onlining and initializing Space.  New Disk is $($disk.Number)"
     $disk | Clear-Disk -RemoveData -RemoveOEM -ErrorAction SilentlyContinue -Confirm:$false
     Sleep -Seconds 5
     $disk | Initialize-Disk -PartitionStyle GPT

     WriteMessageToLogFile "Disk set of $numOfDisks disks - Creation Partition"
     $partition2 = $disk | New-Partition -AssignDriveLetter -UseMaximumSize
     WriteMessageToLogFile "Drive Letter is: $($partition2.DriveLetter)"
     Sleep -Seconds 5
     $volume = Format-Volume -Partition $partition2 -FileSystem NTFS -NewFileSystemLabel "TestVolume$k" -Confirm:$false
     $filePath = "$($partition2.DriveLetter):\TestFile.txt"
     Sleep -Seconds 15
     WriteMessageToLogFile " Volume size  $volume.SizeRemaining "
     $fileSize = $volume.SizeRemaining*.75
     Fsutil file createnew $filePath $fileSize
     Fsutil file setvaliddata $filePath $fileSize
     WriteMessageToLogFile "Created $filePath of Size $fileSize"

     if ((Test-Path $filePath) -eq $false)
     {
         WriteErrorToLogFile 
         WriteMessageToLogFile "File creation for file $filePath failed"
         return  
     }    
  }

 $test = "Mirror Space on enclosure drives"
 $script:logger.StartTest($test)
 CreateEnclosureMirrorSpace
 $script:logger.EndTest($test, $script:pass, "")

 #Wrap-up
 $logger.Trace($script:rollup)
 $logger.Dispose()
