﻿<#

    Copyright (c) 2014 Microsoft Corporation

    Module Name: Cluster drives enumeration test 

    Abstract:

    Shared Drives from enclosure is enumerated from each Node and compared if list from other Nodes

    Author(s): umani

    Environment: User Mode

    Revision History:
    Enumerate drives from each Node and compare with drives from other nodes.


    Description:
    A. Create a cluster with enclosure connected each node
    B. Run the test on a node connected to 2 or more Enclosures.

#>


param (
    $EnclosureVPD = $null
    )


$sysRoot = $env:SystemRoot
$gacFilePath = "Assembly\Gac\Microsoft.Wtt.Log"
$gacdir = $sysRoot + "\" + $gacFilePath
$gacdir1 = $gacdir  + "\*2.2*"
$gacdirName = dir $gacdir1
$loggerPath = $gacdir + "\" + $gacdirName.Name
write $loggerPath

$lib = $loggerPath + "\" + "Microsoft.wtt.log.dll"
[Reflection.Assembly]::LoadFile($lib)

#6b. Enhanced data structures
[Reflection.Assembly]::Load("mscorlib.dll")

#7. Create logger object

$mins = (Get-Date).TimeOfDay.TotalMinutes
$fileName= "Spaces$mins"
$config = "`$console;`$logfile:file=$fileName.wtl,Writemode=overwrite"#,encoding=UNICODE"
$logger = new-object Microsoft.DistributedAutomation.Logger.TestLogger $config
$rollup = new-object Microsoft.DistributedAutomation.Logger.LevelRollup(0, 0, 0, 0, 0)
$pass = 0x1
$fail = 0x2
$scenario = 0

<#
    Description:
This function is used to write message to WTT log file

    Arguments:
text - string to write

Return Value:
None
#>
function WriteMessageToLogFile($text)
{
    $msg = new-object Microsoft.DistributedAutomation.Logger.LevelMessage $text
    $script:logger.Trace($msg)
}

<#
    Description:
    This function is used to write error message to WTT log file

    Arguments:   None

    Return Value:    None
#>
function WriteErrorToLogFile()
{
    $err = new-object Microsoft.DistributedAutomation.Logger.LevelError(0, 0, 0)
    $script:logger.Trace($err)
}



  <#
   Description:
   This function compares 2 physical disk array

   Arguments:      None

   Return Value:   None
 #>
 function ComparePhysicalDisks($currentNodePDs, $remoteNodePDs)
 {
    foreach($currentPD in $currentNodePDs)
    {
        $bFound = $false;

        foreach($remotePD in $remoteNodePDs)
        {
             if($remotePD.uniqueid -eq $currentPD.uniqueid)
             {
                 if($remotePD.SlotNumber -eq $currentPD.SlotNumber)
                 {
                      WriteMessageToLogFile "Physicaldisk found a match uniqueID $remotePD.uniqueid"
                      $bFound = $true;
                      break;
                 }
                 else
                 {
                      WriteErrorToLogFile 
                      WriteMessageToLogFile "Drive with unique ID has different slot number on both nodes with slot values $currentPD.SlotNumber and $remotePD.SlotNumber"
                 }
             }
        }

        if($bFound -eq $false)
        {
               WriteErrorToLogFile 
               WriteMessageToLogFile "Did not find a match for PD $currentPD.uniqueid"
        }
    }
 }


  <#
   Description:
   Shared Drives from enclosure is enumerated from each Node and compared if list from other Nodes

   Arguments:      None

   Return Value:   None
 #>
 function ClusterDriveEnumerationTest()
 { 
    WriteMessageToLogFile "Testing enclosure with unique id: $EnclosureVPD"
 
     $clus = get-cluster
     if($clus -eq $null)
     {         
         WriteMessageToLogFile "No cluster found, terminating test"
         return
     }
     WriteMessageToLogFile "Discovered cluster $clus"
    

     $AllClusNodes = $clus | Get-ClusterNode
     $outvar = $clus | Get-ClusterNode | out-string
     WriteMessageToLogFile "Nodes on the cluster are $outvar"

     $OtherClusNodes = New-Object System.Collections.ArrayList
    
     foreach($node in $AllClusNodes)
     {
       if($env:COMPUTERNAME.ToLower() -ne $node.Name.ToLower())
       {
          $OtherClusNodes.Add($node);
       }
     }

     $enclosure = Get-StorageEnclosure -UniqueId $EnclosureVPD
     $NumberofPDinEnclosure = (Get-StorageEnclosure -UniqueId $EnclosureVPD | Get-physicaldisk).count
     if ( $enclosure.NumberOfSlots -ne $NumberofPDinEnclosure )
     {
        WriteErrorToLogFile 
        WriteMessageToLogFile "Number of Slots $enclosure.NumberofSlots and Number of Physical Disks $remotePD.SlotNumber are not the same. Enclosure needs to be fully populated."
     }
     
     if($enclosure -eq $null)
     {
         $CurrentNodePDs = get-physicaldisk | select friendlyname,enclosurenumber,uniqueid,slotnumber
         $outvar = get-physicaldisk | select friendlyname,enclosurenumber,uniqueid,slotnumber  | out-string
         
         WriteMessageToLogFile "Physicaldisks on Node $env:COMPUTERNAME are "
         WriteMessageToLogFile $outvar
                  
         WriteMessageToLogFile "Enumerate all the nodes in the cluster and compare the disks from the enclosure"
         foreach($node in $OtherClusNodes)
         {
           WriteMessageToLogFile "Enumerating Node $node"
           $RemoteNodePDs = Invoke-Command -ComputerName $node -Command { get-physicaldisk | ? enclosurenumber -NE $null| select friendlyname,enclosurenumber,uniqueid,slotnumber }

           ComparePhysicalDisks $CurrentNodePDs $RemoteNodePDs
         }
     } 
     else
     {        
             $CurrentNodePDs = $enclosure | get-physicaldisk | select friendlyname,enclosurenumber,uniqueid,slotnumber
             $outvar = $enclosure | get-physicaldisk | select friendlyname,enclosurenumber,uniqueid,slotnumber  | out-string
             WriteMessageToLogFile "Physicaldisks of enclosure $($enclosure.FriendlyName) on Node $env:COMPUTERNAME are "
             WriteMessageToLogFile $outvar

             WriteMessageToLogFile "Enumerate all the nodes in the cluster and compare the disks from the enclosure $($enclosure.FriendlyName)"
             foreach($node in $OtherClusNodes)
             {
               WriteMessageToLogFile "Enumerating Node $node"
               $enclosureUniqueID = $($enclosure.UniqueId)
               $session = New-Pssession -ComputerName $node

               $RemoteNodePDs = Invoke-Command -ScriptBlock {
                    Param ($encUniqueID)

                    get-storageenclosure -UniqueId $encUniqueID | get-physicaldisk | select friendlyname,enclosurenumber,uniqueid,slotnumber 

                } -ArgumentList $enclosureUniqueID -Session $session

               ComparePhysicalDisks $CurrentNodePDs $RemoteNodePDs

               Remove-PSSession  $session               
             }  
        
     }
 }


 $test = "Cluster drive enumeration test"
 $script:logger.StartTest($test)
 ClusterDriveEnumerationTest
 $script:logger.EndTest($test, $script:pass, "")

 #Wrap-up
 $logger.Trace($script:rollup)
 $logger.Dispose()


