﻿param([string]$targetServer = $args[0], [string]$drvletter = $args[1], [string]$targetName = $args[2])

cls
write-Host "`n"
Write-Host "Target Server: $targetServer"
Write-Host "Target Name: $targetName"
Write-Host "Drives List: $drvletter"
    
$socket = "3260"

$computerName = get-content env:COMPUTERNAME

Set-Service msiscsi -StartupType Automatic
Start-Service msiscsi

Sleep 3

function Setup([string]$targetServer,
                      [string]$targetName,
                    [string]$drvletter)
{


$driveletter = $drvletter.split(" ")
if ($driveletter.length -eq 0) {exit;}

Write-Host "Trace:: iscsicli QAddTargetPortal $targetServer"-foregroundcolor red -backgroundcolor yellow
iscsicli QAddTargetPortal $targetServer
write-host $LastExitCode

if ($LastExitCode -eq -268500969) {
    Write-Warning "Unable to connect to server. Exiting!!!"
    break
    }  #already logged in error

iscsicli ListTargets True

[int]$icount = 0

    foreach ($drv in $driveletter) {
    
        $drv = $drv.Substring(0,1)
        $iqnName = $targetName

        iscsicli RemoveTarget $iqnName >NULL
        sleep 5
   

         Write-Host "Trace:: iscsicli QLoginTarget $iqnName" -foregroundcolor red -backgroundcolor yellow
         iscsicli QLoginTarget $iqnName

    
        iscsicli ListTargets True

        $txtFile = ".\script.txt"
        if (Test-Path -path ".\script.txt") {del ".\script.txt"}
        $volumes = get-wmiobject Win32_DiskDrive | where caption -ne "MSFT Virtual HD SCSI Disk Device"
    
        [int]$num = 0
        foreach ($disk in $volumes) {
    	    $num++
    	    }
        $num = $num + $icount
        write-Host "`n            " -NoNewline
        write-host "Trace:: Setting up Disk$num for use" -foregroundcolor red -backgroundcolor yellow

        Add-Content $txtFile "select disk $num"
        Add-Content $txtFile "ATTRIBUTES DISK CLEAR READONLY noerr"
        Add-Content $txtFile "offline disk noerr"
        Add-Content $txtFile "online disk"
        Add-Content $txtFile "clean"
        Add-Content $txtFile "create partition pri"
        Add-Content $txtFile "assign letter=$drv"
        Add-Content $txtFile 'FORMAT FS=NTFS LABEL="" QUICK'
        Add-Content $txtFile 'detail disk'
        
        Get-Content .\script.txt
        write-Host "`n" -foregroundcolor red -backgroundcolor yellow

        diskpart /s .\script.txt
        write-Host "`n"
        $icount++
    }
}

function Cleanup([string]$targetServer,
                     [string]$targetName)
            
{

    do {
        Write-Host "Trace:: iscsicli SessionList" -foregroundcolor red -backgroundcolor yellow
        iscsicli SessionList > .\sesslist.txt
        Get-Content .\sesslist.txt
        if ($LastExitCode -eq -268500929) {
            break
            }  #already logged in error
        if ($LastExitCode -ne 0) {
            Write-Warning "Error: $LastExitCode"
            sleep 9
            }
        sleep 1
        }
    while ($LastExitCode -ne 0)

    $a = Select-String -Path .\sesslist.txt -pattern "Session Id" -AllMatches
    foreach ($b in $a) {
        if ($b) {
            [int]$errloop = 0
            [int]$charLoc = $b.Line.IndexOfAny(":") + 2
            $session = $b.line.remove(0,$charLoc)
            do {
                Write-Host "Trace:: iscsicli LogoutTarget $session" -foregroundcolor red -backgroundcolor yellow
                iscsicli LogoutTarget $session
                if ($LastExitCode -ne 0) {
                    if ($errloop -gt 6) {break;}  #we shouldn't get stuck here
                    Write-Warning "Error: $LastExitCode"
                    sleep 9
                    $errloop = $errloop + 1
                    }  
                }
            while ($LastExitCode -ne 0)       
            }
        }


    foreach ($eachtarg in $targetName) {
        do {
            Write-Host "Trace:: iscsicli RemoveTarget $eachtarg" -foregroundcolor red -backgroundcolor yellow
            iscsicli RemoveTarget $eachtarg
            if ($LastExitCode -eq -268500951) {
                break
                }  #The targetname is not found of is marked as hidden from login
            if ($LastExitCode -ne 0) {
                Write-Warning "Error: $LastExitCode"
                sleep 9
                }
            sleep 1
            }
        while ($LastExitCode -ne 0)
    }

    Write-Host "Trace:: iscsicli RemoveTargetPortal $targetServer $socket" -foregroundcolor red -backgroundcolor yellow
    iscsicli RemoveTargetPortal $targetServer $socket

}

if ($drvletter.Contains("0"))
{
    Write-Host "Calling Cleanup"
    Cleanup $targetServer $targetName
    
}
else
{
    Write-Host "Calling Setup"
    Setup $targetServer $targetName $drvletter
}
