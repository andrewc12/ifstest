﻿Param ([string] $clusterName = "JTTZ1")

$grps = Get-ClusterGroup -Cluster $clusterName | where {$_.name -ne "cluster group" -and $_.name -ne "Available Storage"} 

foreach ($grp in $grps)
{
    Write-Host Deleting $grp.Name ...
    Remove-ClusterGroup -Cluster $clusterName -Name $grp.Name -Force -RemoveResources
    Get-AdComputer $grp.Name | remove-AdComputer -confirm:$false
}
Remove-Cluster -Cluster $clusterName -Force -CleanupAD