﻿Param ([string[]] $nodeNames = @("28-3073A0108","28-3073A0107")
       )

# on client machine
net use * /delete /Y
Disconnect-IscsiTarget -Confirm:$false
Get-IscsiTargetPortal | Remove-IscsiTargetPortal -Confirm:$false

#on server nodes

foreach ($node in $nodeNames)
{
    $session = New-PSSession -ComputerName $node -EnableNetworkAccess
    Invoke-Command -Session $session -Script{get-smbshare -Name smbShare* | Remove-SmbShare -Confirm:$false}
    Invoke-Command -Session $session -Script{get-smbshare -Name scSmbShr* | Remove-SmbShare -Confirm:$false}
    Invoke-Command -Session $session -Script{Get-NfsShare -Name nfsShare* | Remove-NfsShare -Confirm:$false}
    Invoke-Command -Session $session -Script{Get-IscsiServerTarget | Remove-IscsiServerTarget}
    Invoke-Command -Session $session -Script{Get-IscsiVirtualDisk | Remove-IscsiVirtualDisk}
}
